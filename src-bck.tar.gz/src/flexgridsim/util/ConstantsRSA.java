package flexgridsim.util;

/**
 * The Class ConstantsRSA.
 * 
 * @author pedrom
 */
public class ConstantsRSA {
	
	/** The Constant INFINITE represents a value that is big but not too big, 
	 * for avoiding overflows. */
	public static final double INFINITE = 100000.0;

}
