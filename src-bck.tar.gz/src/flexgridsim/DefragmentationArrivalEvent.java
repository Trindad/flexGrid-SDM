package flexgridsim;

/**
 * 
 * @author trindade
 *
 */
public class DefragmentationArrivalEvent extends Event{

	public DefragmentationArrivalEvent(double time) {
		super(time);
	}

}
