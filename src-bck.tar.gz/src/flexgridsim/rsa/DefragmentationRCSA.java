package flexgridsim.rsa;

public abstract class DefragmentationRCSA extends SCVCRCSA {
	
	public abstract void runDefragmentantion();

}
